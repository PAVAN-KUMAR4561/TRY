import { JsonPipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FormsModule,JsonPipe,ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  

  // template form

  // studentObj:any ={
  //   firstName:"",
  //   lastName:"",
  //   userName:"",
  //   city:"",
  //   state:"",
  //   zipCode:"",
  //   isAcceptTerms:false

  // }
  // formValue:any;

  // onSubmit(){
  //   debugger;
  //   this.formValue = this.studentObj;
  // }
  // resetForm(){
  //   this.studentObj={
  //     firstName:"",
  //     lastName:"",
  //     userName:"",
  //     city:"",
  //     state:"",
  //     zipCode:"",
  //     isAcceptTerms:false
  
  //   }
  // }


  //  reactive form


  studentForm: FormGroup = new FormGroup({
    firstName:new FormControl("",[Validators.required,Validators.minLength(4)]),
    lastName:new FormControl(""),
    city:new FormControl(""),
    state:new FormControl(""),
    zipcode:new FormControl(""),
    isAcceptTerms:new FormControl(""),

  });

  formValue:any;

  onSave(){
    this.formValue=this.studentForm.value;
  }


}
